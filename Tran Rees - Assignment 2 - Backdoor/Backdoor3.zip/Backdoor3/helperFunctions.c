#include "helperFunctions.h"


/*
 * I found this function on stackoverflow in a thread titled
 * "simple XOR algorithm"
 * */
char *xor_encrypt(char *key, char *string)
{
	int i, x, y;
    
    x = strlen(string);
    y = strlen(key);
    
    for (i = 0; i < x; ++i)
    {
        string[i] ^= key[(i%y)];
    }
    return string;
}
