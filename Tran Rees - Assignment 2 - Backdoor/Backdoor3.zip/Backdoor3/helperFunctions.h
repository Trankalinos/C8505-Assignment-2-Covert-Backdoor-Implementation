#ifndef HELPERFUNCTIONS_H
#define HELPERFUNCTIONS_H
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define encryptKey "netw"
#define password "comp"

char *xor_encrypt(char *key, char *string);
#endif
